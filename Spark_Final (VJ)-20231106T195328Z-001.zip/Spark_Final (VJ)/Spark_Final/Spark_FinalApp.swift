//
//  Spark_FinalApp.swift
//  Spark_Final
//
//  Created by Avihhan Arya Kumarr and Vijay Wulfekuhle on 11/5/23.
//

import SwiftUI

@main
struct Spark_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
